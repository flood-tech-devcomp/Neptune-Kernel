# Set up Multiboot constants
.set MAGIC,    0x1BADB002
.set FLAGS,    0x00000003
.set CHECKSUM, -(MAGIC + FLAGS)

.section .multiboot
.align 4
.long MAGIC
.long FLAGS
.long CHECKSUM

.section .bss
.align 16
stack_bottom:
.skip 16384 # 16 KiB
stack_top:

.section .text
.global _start
.global keyboard_asm_handler
.extern keyboard_handler

_start:
    mov $stack_top, %esp
    call kernel_main

_halt:
    cli
    hlt
    jmp _halt

# The safe wrapper for our keyboard interrupt handler
keyboard_asm_handler:
    pusha                  # Save all CPU registers so we don't corrupt C code

    call keyboard_handler  # Call your actual C keyboard logic safely

    # Send End-Of-Interrupt (EOI) signal to the PIC controller (Port 0x20)
    mov $0x20, %al
    out %al, $0x20

    popa                   # Restore all CPU registers back to normal
    iret                   # Safe Interrupt Return instruction!
