#define VGA_WIDTH 80

// A basic lookup table (Scancode Map) to convert raw hardware signals into letters
// This covers standard lowercase letters, numbers, and space
static const char scancode_to_ascii[] = {
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
  '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0,  'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',   0,
 '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/',   0, '*',   0, ' '
};

// Global cursor tracker to know where to print characters on the screen
static int cursor_position = 80 * 2; // Start on line 2 (Line 1 has the welcome message)

// Helper function to read a single byte directly from a hardware chip port
unsigned char inb(unsigned short port) {
    unsigned char result;
    __asm__ volatile("inb %1, %0" : "=a"(result) : "Nd"(port));
    return result;
}

// The main keyboard handling function
void keyboard_handler(void) {
    // Read the character data code from the keyboard controller port (0x60)
    unsigned char scancode = inb(0x60);
    volatile char* video_memory = (volatile char*)0xB8000;

    // The keyboard sends a signal when a key is pressed, and a different one when released.
    // If the highest bit is set, it means the key was released. We only care about presses.
    if (!(scancode & 0x80)) {

        // Make sure the scancode is within our known lookup table array
        if (scancode < sizeof(scancode_to_ascii)) {
            char ascii = scancode_to_ascii[scancode];

            if (ascii != 0) {
                // Print the typed character directly to the cursor spot on the screen
                video_memory[cursor_position * 2] = ascii;
                video_memory[cursor_position * 2 + 1] = 0x0F; // Pure white text color

                // Advance the cursor forward by 1 character slot
                cursor_position++;

                // Wrap around to the next line if we hit the edge of the screen
                if (cursor_position >= VGA_WIDTH * 25) {
                    cursor_position = 80 * 2; // Reset back to line 2 if screen fills up
                }
            }
        }
    }
}
