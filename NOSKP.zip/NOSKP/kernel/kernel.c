
#define VGA_WIDTH 80
#define VGA_HEIGHT 25

// Link directly to our safe assembly gatekeeper wrapper stub
extern void keyboard_asm_handler(void);

struct IDT_entry {
    unsigned short offset_lowerbits;
    unsigned short selector;
    unsigned char zero;
    unsigned char type_attr;
    unsigned short offset_higherbits;
} __attribute__((packed));

// Declare a full array containing exactly 256 structural descriptors
struct IDT_entry idt[256];

// Helper function to talk directly to motherboard hardware chips
void outb(unsigned short port, unsigned char val) {
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

void idt_init(void) {
    unsigned long keyboard_address = (unsigned long)keyboard_asm_handler;

    // Completely clear all 256 memory spots in our table
    for (int i = 0; i < 256; i++) {
        idt[i].offset_lowerbits = 0;
        idt[i].selector = 0;
        idt[i].zero = 0;
        idt[i].type_attr = 0;
        idt[i].offset_higherbits = 0;
    }

    // Crucial Step: Remap the PIC chips so hardware interrupts don't overlap errors
    outb(0x20, 0x11); // Initialize Master PIC
    outb(0xA0, 0x11); // Initialize Slave PIC
    outb(0x21, 0x20); // Master PIC offset = 32 (Keyboard will live at 33!)
    outb(0xA1, 0x28); // Slave PIC offset = 40
    outb(0x21, 0x04);
    outb(0xA1, 0x02);
    outb(0x21, 0x01);
    outb(0xA1, 0x01);

    // Mask interrupts: Turn off all hardware inputs EXCEPT the master keyboard line (IRQ1)
    outb(0x21, 0xFD); // 0xFD leaves the keyboard unmasked
    outb(0xA1, 0xFF); // Disable all slave interrupts

    // Map array entry 33 safely to our assembly handler
    idt[33].offset_lowerbits = keyboard_address & 0xFFFF;
    idt[33].selector = 0x08; // Kernel code segment offset
    idt[33].zero = 0;
    idt[33].type_attr = 0x8E; // 32-bit Interrupt Gate flag
    idt[33].offset_higherbits = (keyboard_address >> 16) & 0xFFFF;

    struct {
        unsigned short limit;
        unsigned long base;
    } __attribute__((packed)) idt_ptr;

    idt_ptr.limit = (sizeof(struct IDT_entry) * 256) - 1;
    idt_ptr.base = (unsigned long)&idt;

    // Load our table descriptor directly into the CPU chip register
    __asm__ volatile("lidt %0" : : "m"(idt_ptr));
}

void kernel_main(void) {
    volatile char* video_memory = (volatile char*)0xB8000;

    // Clear the monitor view with standard gray characters
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT * 2; i += 2) {
        video_memory[i] = ' ';
        video_memory[i + 1] = 0x07;
    }

    // Print your top welcome header in bright light green
    const char* greeting = "Welcome to the Neptune Open Source Kernel Project (NOSKP)!";
    int index = 0;
    while (greeting[index] != '\0') {
        video_memory[index * 2] = greeting[index];
        video_memory[index * 2 + 1] = 0x0A;
        index++;
    }

    // Initialize our configuration layout safely
    idt_init();

    // Safely un-mute hardware signals!
    __asm__ volatile("sti");

    while (1) {
        // CPU hangs out here waiting for keypress signals
    }
}
